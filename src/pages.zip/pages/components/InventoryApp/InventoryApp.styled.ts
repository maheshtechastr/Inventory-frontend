import styled from 'styled-components';

export const InventoryAppWrapper = styled.div`
    padding: 20px;
    background-color: #f9f9f9;
    font-size: 1.5rem;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
`;
