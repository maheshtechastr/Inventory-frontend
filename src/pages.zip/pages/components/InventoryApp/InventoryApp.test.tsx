import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import InventoryApp from './InventoryApp';

describe('<InventoryApp />', () => {
  test('it should mount', () => {
    render(<InventoryApp />);

    const inventoryApp = screen.getByTestId('InventoryApp');

    expect(inventoryApp).toBeInTheDocument();
  });
});