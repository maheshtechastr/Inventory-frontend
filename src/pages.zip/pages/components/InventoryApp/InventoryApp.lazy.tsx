import React, { lazy, Suspense } from 'react';

const LazyInventoryApp = lazy(() => import('./InventoryApp'));

const InventoryApp = (props: JSX.IntrinsicAttributes & { children?: React.ReactNode; }) => (
  <Suspense fallback={null}>
    <LazyInventoryApp {...props} />
  </Suspense>
);

export default InventoryApp;
