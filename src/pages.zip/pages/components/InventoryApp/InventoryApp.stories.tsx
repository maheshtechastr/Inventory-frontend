/* eslint-disable */
import InventoryApp from './InventoryApp';

export default {
  title: "InventoryApp",
};

export const Default = () => <InventoryApp />;

Default.story = {
  name: 'default',
};
