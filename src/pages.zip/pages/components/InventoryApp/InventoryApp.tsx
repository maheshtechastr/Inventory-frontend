import React, { FC } from 'react';
import { InventoryAppWrapper } from './InventoryApp.styled';

interface InventoryAppProps {}

const InventoryApp: FC<InventoryAppProps> = () => (
 <InventoryAppWrapper data-testid="InventoryApp">
    InventoryApp Component
 </InventoryAppWrapper>
);

export default InventoryApp;
