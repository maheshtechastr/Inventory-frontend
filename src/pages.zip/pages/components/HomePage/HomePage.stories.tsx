/* eslint-disable */
import HomePage from './HomePage';

export default {
  title: "HomePage",
};

export const Default = () => <HomePage />;

Default.story = {
  name: 'default',
};
