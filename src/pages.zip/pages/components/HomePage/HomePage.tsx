import React, { FC } from 'react';
import { HomePageWrapper } from './HomePage.styled';

interface HomePageProps {}

const HomePage: FC<HomePageProps> = () => (
 <HomePageWrapper data-testid="HomePage">
    HomePage Component
 </HomePageWrapper>
);

export default HomePage;
