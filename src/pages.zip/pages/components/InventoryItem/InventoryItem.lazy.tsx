import React, { lazy, Suspense } from 'react';

const LazyInventoryItem = lazy(() => import('./InventoryItem'));

const InventoryItem = (props: JSX.IntrinsicAttributes & { children?: React.ReactNode; }) => (
  <Suspense fallback={null}>
    <LazyInventoryItem {...props} />
  </Suspense>
);

export default InventoryItem;
