/* eslint-disable */
import InventoryItem from './InventoryItem';

export default {
  title: "InventoryItem",
};

export const Default = () => <InventoryItem />;

Default.story = {
  name: 'default',
};
