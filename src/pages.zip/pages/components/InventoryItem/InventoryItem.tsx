import React, { FC } from 'react';
import { InventoryItemWrapper } from './InventoryItem.styled';

interface InventoryItemProps {}

const InventoryItem: FC<InventoryItemProps> = () => (
 <InventoryItemWrapper data-testid="InventoryItem">
    InventoryItem Component
 </InventoryItemWrapper>
);

export default InventoryItem;
