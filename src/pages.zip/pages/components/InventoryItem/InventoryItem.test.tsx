import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import InventoryItem from './InventoryItem';

describe('<InventoryItem />', () => {
  test('it should mount', () => {
    render(<InventoryItem />);

    const inventoryItem = screen.getByTestId('InventoryItem');

    expect(inventoryItem).toBeInTheDocument();
  });
});