/* eslint-disable */
import Contact from './Contact';

export default {
  title: "Contact",
};

export const Default = () => <Contact />;

Default.story = {
  name: 'default',
};
